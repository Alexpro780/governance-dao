# governance-dao

A simple on-chain governance DAO template with proposal and voting stubs.

## Features
- Basic proposal struct
- Voting logic placeholder
- Hardhat project layout

## Tech Stack
- Solidity
- Hardhat
- Node.js
